La tarea debe ser ejecutada con live server debido a que la solicitud CORS no es HTTP, esto es producto de que tome la decisión de almacenar
los datos dentro de un json, para asi hacer mas realista el acceso a una base de datos y tener un código más limpio.

Me disculpo de antemano por el javascript de los validadores, se que se puede hacer mas bonito y mejor, pero esta duro el semestre.

Espero que disfrute de la "Feria Online OMG" Nombre todavía sujeto a cambios. :D
